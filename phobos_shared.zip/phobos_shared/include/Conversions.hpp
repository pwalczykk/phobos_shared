#ifndef MY_CONVERSIONS_HPP_
#define MY_CONVERSIONS_HPP_

#include "OdometryConversions.hpp"
#include "SignalConversion.hpp"

#endif
